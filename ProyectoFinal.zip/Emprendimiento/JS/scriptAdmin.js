$(document).ready(function(){

	$("#proyectosNuevosBtn").on("click", function(){
		cargarProyectosN();
	});

	$("#findAllProjectsN").on("click", function(){
		cargarProyectosN();
	});

	// Buscar Proyectos en Historial
	$("#searchHBtn").on("click", function(){
        if($("#searchTextH").val() != ""){
            var jsonToSend = {
                "action" : "SEARCHPROJECTS",
                "search" : $("#searchTextH").val()
            }
            $.ajax({
                url : "data/applicationLayer.php",
                type : "POST",
                data : jsonToSend,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success: function(jsonResponse){
                    if(jsonResponse.status == "SUCCESS"){
                        $("#projectsListH tr").remove();
                        for (var i = 0; i <= jsonResponse[0].length; i++) {
                            $(jsonResponse[0][i]).each(function(){
                            	var row = $("<tr>"); 
		                        row.append($("<th>").text("Nombre del Proyecto"));
		                        row.append( $("<td>").text(jsonResponse[0][i].nombre));
		                        row.append( $("<th>").text("Descripcion del Negocio"));
		                        row.append( $("<th>").text("Giro del negocio"));
		                        $("#projectsListH").append(row); 
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Empresa"));
		                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
		                        $("#projectsListH").append(row); // agregar renglon a la tabla
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Clasificacion Sectorial"));
		                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
					        	$("#projectsListH").append(row); // agregar renglon a la tabla
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Semestre"));
		                        row.append( $('<td>').text(jsonResponse[0][i].semestre));
		                        $("#projectsListH").append(row); // agregar renglon a la tabla
		                        $("#projectsListH").append($('<tr style="color: black;">').append( $('<td colspan="4">')));
                            });
                        }
                        $("#projectsListH").show();
                        $("#findNoMatchH").hide();
                    }
                    else if(jsonResponse.status == "NO MATCHES FOUND"){
                        $("#projectsListH").hide();
                        $("#findNoMatchH").show();
                    }
                },
                error: function(errorMessage){
                    alert(errorMessage.responseText);
                }
            });
        }
        else{
            alert("Filtra Proyectos por Nombre, Clasificación Sectorial o Semestre");
        }
    });

	// Buscar Proyectos en Semestre Actual
    $("#searchNBtn").on("click", function(){
        if($("#searchTextN").val() != ""){
            var jsonToSend = {
                "action" : "SEARCHPROJECTSADMIN",
                "search" : $("#searchTextN").val()
            }
            $.ajax({
                url : "data/applicationLayer.php",
                type : "POST",
                data : jsonToSend,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success: function(jsonResponse){
                    if(jsonResponse.status == "SUCCESS"){
                        $("#projectsListN tr").remove();
                        for (var i = 0; i <= jsonResponse[0].length; i++) {
                            $(jsonResponse[0][i]).each(function(){
                            	var row = $("<tr>"); 
		                        row.append( $("<th>").text("Nombre del Proyecto"));
		                        row.append( $('<td>').text(jsonResponse[0][i].nombre));
		                        
		                        row.append( $("<th>").text("Descripcion del Negocio"));
		                        row.append( $("<th>").text("Giro del negocio"));
		                        row.append($("<th>").text("Profesor"));
		                        row.append( $("<td>").text(jsonResponse[0][i].profesor));
		                        $("#projectsListN").append(row); 
		                    	row = $("<tr>"); 
		                    	row.append( $("<th>").text("Empresa"));
		                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
		                        
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
		                        row.append($("<th>").text("Grupo"));
		                        row.append( $("<td>").text(jsonResponse[0][i].grupo));
		                        $("#projectsListN").append(row);
		                       
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Clasificacion Sectorial"));
		                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
		                        var abc = $('<tr>');
		                        var auxi = $('<tr>');
		                        auxi.append( $("<th>").text("Prioridad"));
		                        auxi.append( $('<td>').text(jsonResponse[0][i].rank));
		                        var aux = $('<tr>');
		                        aux.append( $("<th>").text("Apto"));
		                        aux.append( $('<td>').text(jsonResponse[0][i].apto));
		                        abc.append(auxi);
		                        abc.append(aux);
		                        row.append(abc);
		                        $("#projectsListN").append(row); // agregar renglon a la tabla
                        		$("#projectsListN").append($('<tr>').append( $('<td colspan="6">')));
                            });
                        }
                        $("#projectsListN").show();
                        $("#findNoMatchN").hide();
                    }
                    else if(jsonResponse.status == "NO MATCHES FOUND"){
                        $("#projectsListN").hide();
                        $("#findNoMatchN").show();
                    }
                },
                error: function(errorMessage){
                    alert(errorMessage.responseText);
                }
            });
        }
        else{
            alert("Filtra Proyectos por Nombre, Clasificación Sectorial o Semestre");
        }
    });

    // Buscar proyectos anteriores
    $("#searchHBtn").on("click", function(){
        if($("#searchTextH").val() != ""){
            var jsonToSend = {
                "action" : "SEARCHPROJECTS",
                "search" : $("#searchTextH").val()
            }
            $.ajax({
                url : "data/applicationLayer.php",
                type : "POST",
                data : jsonToSend,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success: function(jsonResponse){
                    if(jsonResponse.status == "SUCCESS"){
                        $("#projectsListH tr").remove();
                        for (var i = 0; i <= jsonResponse[0].length; i++) {
                            $(jsonResponse[0][i]).each(function(){
                            	var row = $("<tr>"); 
		                        row.append($("<th>").text("Nombre del Proyecto"));
		                        row.append( $("<td>").text(jsonResponse[0][i].nombre));
		                        row.append( $("<th>").text("Descripcion del Negocio"));
		                        row.append( $("<th>").text("Giro del negocio"));
		                        $("#projectsListH").append(row); 
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Empresa"));
		                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
		                        $("#projectsListH").append(row); // agregar renglon a la tabla
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Clasificacion Sectorial"));
		                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
					        	$("#projectsListH").append(row); // agregar renglon a la tabla
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Semestre"));
		                        row.append( $('<td>').text(jsonResponse[0][i].semestre));
		                        $("#projectsListH").append(row); // agregar renglon a la tabla
		                        $("#projectsListH").append($('<tr style="color: black;">').append( $('<td colspan="4">')));
                            });
                        }
                        $("#projectsListH").show();
                        $("#findNoMatchH").hide();
                    }
                    else if(jsonResponse.status == "NO MATCHES FOUND"){
                        $("#projectsListH").hide();
                        $("#findNoMatchH").show();
                    }
                },
                error: function(errorMessage){
                    alert(errorMessage.responseText);
                }
            });
        }
        else{
            alert("Filtra Proyectos por Nombre, Clasificación Sectorial o Semestre");
        }
    });

    $("#listar").on("click", function(){
    	var jsonToSend = {
	        "action" : "GENERARLISTA"
	    };
	    $.ajax({
                url : "data/applicationLayer.php",
                type : "POST",
                data : jsonToSend,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success: function(jsonResponse){
                    if(jsonResponse.status == "SUCCESS"){
                        $("#projectsListN tr").remove();
                        for (var i = 0; i <= jsonResponse[0].length; i++) {
                            $(jsonResponse[0][i]).each(function(){
                            	var row = $("<tr>"); 
		                        row.append( $("<th>").text("Nombre del Proyecto"));
		                        row.append( $('<td>').text(jsonResponse[0][i].nombre));
		                        
		                        row.append( $("<th>").text("Descripcion del Negocio"));
		                        row.append( $("<th>").text("Giro del negocio"));
		                        row.append($("<th>").text("Profesor"));
		                        row.append( $("<td>").text(jsonResponse[0][i].profesor));
		                        $("#projectsListN").append(row); 
		                    	row = $("<tr>"); 
		                    	row.append( $("<th>").text("Empresa"));
		                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
		                        
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
		                        row.append($("<th>").text("Grupo"));
		                        row.append( $("<td>").text(jsonResponse[0][i].grupo));
		                        $("#projectsListN").append(row);
		                       
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Clasificacion Sectorial"));
		                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
		                        var abc = $('<tr>');
		                        var auxi = $('<tr>');
		                        auxi.append( $("<th>").text("Prioridad"));
		                        auxi.append( $('<td>').text(jsonResponse[0][i].rank));
		                        var aux = $('<tr>');
		                        aux.append( $("<th>").text("Apto"));
		                        aux.append( $('<td>').text(jsonResponse[0][i].apto));
		                        abc.append(auxi);
		                        abc.append(aux);
		                        row.append(abc);
		                        $("#projectsListN").append(row); // agregar renglon a la tabla
                        		$("#projectsListN").append($('<tr>').append( $('<td colspan="6">')));
                            });
                        }
                        $("#projectsListN").show();
                        $("#findNoMatchN").hide();
                    }
                    else if(jsonResponse.status == "NO MATCHES FOUND"){
                        $("#projectsListN").hide();
                        $("#findNoMatchN").show();
                    }
                },
                error: function(errorMessage){
                    alert(errorMessage.responseText);
                }
            });
    });

});

function cargarProyectosN()
{
	var jsonToSend = {
        "action" : "LOADPROJECTSADMIN"
    };

    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType : "application/x-www-form-urlencoded",
        success: function(jsonResponse){
        	$("#proyectosNuevos").show();
        	$("#proyectosNuevosBtn").css({
        		'background-color' : '#999',
        		'color' : 'white'
        	});

            if(jsonResponse.status == "SUCCESS"){
                $("#projectsListN tr").remove();
                for (var i = 0; i <= jsonResponse[0].length; i++) {
                    $(jsonResponse[0][i]).each(function(){
                        var row = $("<tr>"); 
                        row.append( $("<th>").text("Nombre del Proyecto"));
                        row.append( $('<td>').text(jsonResponse[0][i].nombre));
                        
                        row.append( $("<th>").text("Descripcion del Negocio"));
                        row.append( $("<th>").text("Giro del negocio"));
                        row.append($("<th>").text("Profesor"));
                        row.append( $("<td>").text(jsonResponse[0][i].profesor));
                        $("#projectsListN").append(row); 
                    	row = $("<tr>"); 
                    	row.append( $("<th>").text("Empresa"));
                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
                        
                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
                        row.append($("<th>").text("Grupo"));
                        row.append( $("<td>").text(jsonResponse[0][i].grupo));
                        $("#projectsListN").append(row);
                       
                        row = $("<tr>"); //  crear nuevo renglon
                        row.append( $("<th>").text("Clasificacion Sectorial"));
                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
                        var abc = $('<tr>');
                        var auxi = $('<tr>');
                        auxi.append( $("<th>").text("Prioridad"));
                        auxi.append( $('<td>').text(jsonResponse[0][i].rank));
                        var aux = $('<tr>');
                        aux.append( $("<th>").text("Apto"));
                        aux.append( $('<td>').text(jsonResponse[0][i].apto));
                        abc.append(auxi);
                        abc.append(aux);
                        row.append(abc);
                        
                        //row.append( $("<td>").text(jsonResponse[0][i].grupo));
			        	$("#projectsListN").append(row); // agregar renglon a la tabla
                        $("#projectsListN").append($('<tr>').append( $('<td colspan="6">')));
                    });
                }
                $("#projectsListN").show();
                $("#findNoMatchN").hide();
            }
            else if(jsonResponse.status == "NO MATCHES FOUND"){
                $("#projectsListN").hide();
                $("#findNoMatchN").show();
            }
        },
        error: function(errorMessage){
            alert(errorMessage.responseText);
        }
    });
}

function cargarProyectosH()
{
	var jsonToSend = {
        "action" : "LOADPREVIOUSPROJECTS"
    };

    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType : "application/x-www-form-urlencoded",
        success: function(jsonResponse){
        	
        	// tabs css
	        $("#menu li > input[type=submit]").css({
	    		'background-color' : '#CCC',
	    		'color' : '#003399'
	    	});
	        $("#historialBtn").css({
	    		'background-color' : '#999',
	    		'color' : 'white'
	    	});
            if(jsonResponse.status == "SUCCESS"){
                $("#projectsListH tr").remove();
                for (var i = 0; i <= jsonResponse[0].length; i++) {
                    $(jsonResponse[0][i]).each(function(){
                        var row = $("<tr>"); 
                        row.append($("<th>").text("Nombre del Proyecto"));
                        row.append( $("<td>").text(jsonResponse[0][i].nombre));
                        row.append( $("<th>").text("Descripcion del Negocio"));
                        row.append( $("<th>").text("Giro del negocio"));
                        $("#projectsListH").append(row); 
                        row = $("<tr>"); //  crear nuevo renglon
                        row.append( $("<th>").text("Empresa"));
                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
                        $("#projectsListH").append(row); // agregar renglon a la tabla
                        row = $("<tr>"); //  crear nuevo renglon
                        row.append( $("<th>").text("Clasificacion Sectorial"));
                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
			        	$("#projectsListH").append(row); // agregar renglon a la tabla
                        row = $("<tr>"); //  crear nuevo renglon
                        row.append( $("<th>").text("Semestre"));
                        row.append( $('<td>').text(jsonResponse[0][i].semestre));
                        $("#projectsListH").append(row); // agregar renglon a la tabla
                        $("#projectsListH").append($('<tr style="color: black;">').append( $('<td colspan="4">')));
                    });
                }
                $("#projectsListH").show();
                $("#findNoMatchH").hide();
            }
            else if(jsonResponse.status == "NO MATCHES FOUND"){
                $("#projectsListH").hide();
                $("#findNoMatchH").show();
            }
        },
        error: function(errorMessage){
            alert(errorMessage.responseText);
        }
    });
}