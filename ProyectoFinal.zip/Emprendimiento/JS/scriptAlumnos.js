$(document).ready(function(){

	checkAlumno();

	$("#homeBtn").on("click", function(){
		$("#registroProyecto").hide();
		$("#miProyecto").hide();
		$("#proyectosPrevios").hide();
		// tabs css
        $("#menu li > input[type=submit]").css({
    		'background-color' : '#CCC',
    		'color' : '#003399'
    	});
        $("#homeBtn").css({
    		'background-color' : '#999',
    		'color' : 'white'
    	});
	});

	$("#nuevoProyectoBtn").on("click", function(){
		$("#registroProyecto").show();
		$("#proyectosPrevios").hide();
		// tabs css
        $("#menu li > input[type=submit]").css({
    		'background-color' : '#CCC',
    		'color' : '#003399'
    	});
        $("#nuevoProyectoBtn").css({
    		'background-color' : '#999',
    		'color' : 'white'
    	});
	});

	$("#proyectosBtn").on("click", function(){
		cargarProyectos();
	});

	$("#findAllProjects").on("click", function(){
		cargarProyectos();
	});

	$("#miProyectoBtn").on("click", function(){
		$("#miProyecto").show();
		$("#editMiProyecto").show();
		$("#proyectosPrevios").hide();
		// tabs css
        $("#menu li > input[type=submit]").css({
    		'background-color' : '#CCC',
    		'color' : '#003399'
    	});
        $("#miProyectoBtn").css({
    		'background-color' : '#999',
    		'color' : 'white'
    	});
	});

	$("#registerBtn").on("click", function(){
		var nombre = $("#nombreProyecto").val();
		var empresa = $("#nombreEmpresa").val();
		var descripcion = $("#descripcion").val();
		var clasificacion = $("#clasificacion").val();
		var giro = $("#giro").val();
		var integrantes = $("#numIntegrantes").val();
		var nombreIntegrante1 = $("#nombreIntegrante1").val();
		var matricula1 = $("#matricula1").val();
		var carrera1 = $("#carrera1").val();
		var semestre1 = $("#semestre1").val();
		var emailAcademico1 = $("#emailAcademico1").val();
		var emailPersonal1 = $("#emailPersonal1").val();
		var celular1 = $("#celular1").val();
		var nombreIntegrante2 = $("#nombreIntegrante2").val();
		var matricula2 = $("#matricula2").val();
		var carrera2 = $("#carrera2").val();
		var semestre2 = $("#semestre2").val();
		var emailAcademico2 = $("#emailAcademico2").val();
		var emailPersonal2 = $("#emailPersonal2").val();
		var celular2 = $("#celular2").val();
		var nombreIntegrante3 = $("#nombreIntegrante3").val();
		var matricula3 = $("#matricula3").val();
		var carrera3 = $("#carrera3").val();
		var semestre3 = $("#semestre3").val();
		var emailAcademico3 = $("#emailAcademico3").val();
		var emailPersonal3 = $("#emailPersonal3").val();
		var celular3 = $("#celular3").val();
		var nombreIntegrante4 = $("#nombreIntegrante4").val();
		var matricula4 = $("#matricula4").val();
		var carrera4 = $("#carrera4").val();
		var semestre4 = $("#semestre4").val();
		var emailAcademico4 = $("#emailAcademico4").val();
		var emailPersonal4 = $("#emailPersonal4").val();
		var celular4 = $("#celular4").val();
		var nombreIntegrante5 = $("#nombreIntegrante5").val();
		var matricula5 = $("#matricula5").val();
		var carrera5 = $("#carrera5").val();
		var semestre5 = $("#semestre5").val();
		var emailAcademico5 = $("#emailAcademico5").val();
		var emailPersonal5 = $("#emailPersonal5").val();
		var celular5 = $("#celular5").val();
		var nombreIntegrante6 = $("#nombreIntegrante6").val();
		var matricula6 = $("#matricula6").val();
		var carrera6 = $("#carrera6").val();
		var semestre6 = $("#semestre6").val();
		var emailAcademico6 = $("#emailAcademico6").val();
		var emailPersonal6 = $("#emailPersonal6").val();
		var celular6 = $("#celular6").val();
		var nombreIntegrante7 = $("#nombreIntegrante7").val();
		var matricula7 = $("#matricula7").val();
		var carrera7 = $("#carrera7").val();
		var semestre7 = $("#semestre7").val();
		var emailAcademico7 = $("#emailAcademico7").val();
		var emailPersonal7 = $("#emailPersonal7").val();
		var celular7 = $("#celular7").val();
		var cont = 0;
		if (nombre == "" || empresa == "" || clasificacion == "0" || integrantes == "" || descripcion == ""){
			alert("Debes llenar todos los campos.");
		}
		else{
			var nombreA = [];
			var matriculaA = [];
			var carreraA = [];
			var emailAcademicoA = [];
			var emailPersonalA = [];
			var celularA = [];
			if (nombreIntegrante1 != "" && matricula1 != "" && carrera1 != "" && semestre1 != "" 
				&& emailAcademico1 != "" && emailPersonal1 != "" && celular1 != ""){
				cont += 1;
				nombreA.push(nombreIntegrante1);
				matriculaA.push(matricula1);
				carreraA.push(carrera1);
				emailAcademicoA.push(emailAcademico1);
				emailPersonalA.push(emailPersonal1);
				celularA.push(celular1);
			}
			if (nombreIntegrante2 != "" && matricula2 != "" && carrera2 != "" && semestre2 != "" 
				&& emailAcademico2 != "" && emailPersonal2 != "" && celular2 != ""){
				cont += 1;
				nombreA.push(nombreIntegrante2);
				matriculaA.push(matricula2);
				carreraA.push(carrera2);
				emailAcademicoA.push(emailAcademico2);
				emailPersonalA.push(emailPersonal2);
				celularA.push(celular2);
			}
			if (nombreIntegrante3 != "" && matricula3 != "" && carrera3 != "" && semestre3 != "" 
				&& emailAcademico3 != "" && emailPersonal3 != "" && celular3 != ""){
				cont += 1;
				nombreA.push(nombreIntegrante3);
				matriculaA.push(matricula3);
				carreraA.push(carrera3);
				emailAcademicoA.push(emailAcademico3);
				emailPersonalA.push(emailPersonal3);
				celularA.push(celular3);
			}
			if (nombreIntegrante4 != "" && matricula4 != "" && carrera4 != "" && semestre4 != "" 
				&& emailAcademico4 != "" && emailPersonal4 != "" && celular4 != ""){
				cont += 1;
				nombreA.push(nombreIntegrante4);
				matriculaA.push(matricula4);
				carreraA.push(carrera4);
				emailAcademicoA.push(emailAcademico4);
				emailPersonalA.push(emailPersonal4);
				celularA.push(celular4);
			}
			if (nombreIntegrante5 != "" && matricula5 != "" && carrera5 != "" && semestre5 != "" 
				&& emailAcademico5 != "" && emailPersonal5 != "" && celular5 != ""){
				cont += 1;
				nombreA.push(nombreIntegrante5);
				matriculaA.push(matricula5);
				carreraA.push(carrera5);
				emailAcademicoA.push(emailAcademico5);
				emailPersonalA.push(emailPersonal5);
				celularA.push(celular5);
			}
			if (nombreIntegrante6 != "" && matricula6 != "" && carrera6 != "" && semestre6 != "" 
				&& emailAcademico6 != "" && emailPersonal6 != "" && celular6 != ""){
				cont += 1;
				nombreA.push(nombreIntegrante6);
				matriculaA.push(matricula6);
				carreraA.push(carrera6);
				emailAcademicoA.push(emailAcademico6);
				emailPersonalA.push(emailPersonal6);
				celularA.push(celular6);
			}
			if (nombreIntegrante7 != "" && matricula7 != "" && carrera7 != "" && semestre7 != "" 
				&& emailAcademico7 != "" && emailPersonal7 != "" && celular7 != ""){
				cont += 1;
				nombreA.push(nombreIntegrante7);
				matriculaA.push(matricula7);
				carreraA.push(carrera7);
				emailAcademicoA.push(emailAcademico7);
				emailPersonalA.push(emailPersonal7);
				celularA.push(celular7);
			}
			if (cont != integrantes && integrantes > 0){
				alert("Registraste " + cont + " integrantes, pero debiste registrar " + integrantes);
			}
			else{
				var jsonToSend = {
					"action" : "REGISTERPROJECT",
					"nombre" : nombre,
					"empresa" : empresa,
					"descripcion" : descripcion,
					"giro" : giro,
					"clasificacion" : clasificacion,
					"integrantes" : integrantes,
					"nombreArr" : nombreA,
					"matriculaArr" : matriculaA,
					"carreraArr" : carreraA,
					"emailAcademicoArr" : emailAcademicoA,
					"emailPersonalArr" : emailPersonalA,
					"celularArr" : celularA
				}
				$.ajax({
	                url : "data/applicationLayer.php",
	                type : "POST",
	                data : jsonToSend,
	                dataType : "json",
	                contentType : "application/x-www-form-urlencoded",
	                success : function(jsonResponse){

	                	var row = $('<tr style="display: none;">'); // crear renglon en la tabla
		                row.append( $("<td>").text(jsonResponse.proyectoId));
		                $("#editMiProyecto").append(row); // agregar renglon a la tabla
		                row = $("<tr>"); //  crear nuevo renglon
		                row.append($("<th>").text("Nombre del Proyecto"));
		                row.append( $("<td>").append($('<input id="editNombre" type="text">').val(jsonToSend.nombre)));
		                row.append( $("<th>").text("Descripcion del Negocio"));
		                $("#editMiProyecto").append(row); // agregar renglon a la tabla
		                row = $("<tr>"); //  crear nuevo renglon
		                row.append( $("<th>").text("Empresa"));
		                row.append( $('<td>').append($('<input id="editEmpresa" type="text">').val(jsonToSend.empresa)));
		                row.append( $('<td rowspan="4">').append($('<textarea id="editDescripcion" cols="60" rows="8">').text(jsonToSend.descripcion)));
		                $("#editMiProyecto").append(row); // agregar renglon a la tabla
		                row = $("<tr>"); //  crear nuevo renglon
		                row.append( $("<th>").text("Clasificacion Sectorial"));
		                row.append( $('<td>').append($('<input id="editClasif" type="text">').val(jsonToSend.clasificacion)));
		                $("#editMiProyecto").append(row); // agregar renglon a la tabla
		                row = $("<tr>"); //  crear nuevo renglon
		                row.append( $("<th>").text("Giro del negocio"));
		                row.append( $('<td>').append($('<input id="editGiro" type="text">').val(jsonToSend.giro)));
			        	$("#editMiProyecto").append(row); // agregar renglon a la tabla

		                
			        	$("#miProyectoBtn").show();
			        	$("#miProyecto").show();
		            	$("#nuevoProyectoBtn").hide();
		            	$("#registroProyecto").hide();

		            	// tabs css
				        $("#menu li > input[type=submit]").css({
				    		'background-color' : '#CCC',
				    		'color' : '#003399'
				    	});
				        $("#miProyectoBtn").css({
				    		'background-color' : '#999',
				    		'color' : 'white'
				    	});

	                	alert("success");
	                    //$("#registerForm").hide();
	                },
	                error : function(errorMessage){
	                    alert(errorMessage.responseText);
	                }
	            });
			}
		}
	});

	$("#searchBtn").on("click", function(){
        if($("#searchText").val() != ""){
            var jsonToSend = {
                "action" : "SEARCHPROJECTS",
                "search" : $("#searchText").val()
            }
            $.ajax({
                url : "data/applicationLayer.php",
                type : "POST",
                data : jsonToSend,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success: function(jsonResponse){
                    if(jsonResponse.status == "SUCCESS"){
                        $("#projectsList tr").remove();
                        for (var i = 0; i <= jsonResponse[0].length; i++) {
                            $(jsonResponse[0][i]).each(function(){
                            	var row = $("<tr>"); 
		                        row.append($("<th>").text("Nombre del Proyecto"));
		                        row.append( $("<td>").text(jsonResponse[0][i].nombre));
		                        row.append( $("<th>").text("Descripcion del Negocio"));
		                        row.append( $("<th>").text("Giro del negocio"));
		                        $("#projectsList").append(row); 
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Empresa"));
		                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
		                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
		                        $("#projectsList").append(row); // agregar renglon a la tabla
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Clasificacion Sectorial"));
		                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
					        	$("#projectsList").append(row); // agregar renglon a la tabla
		                        row = $("<tr>"); //  crear nuevo renglon
		                        row.append( $("<th>").text("Semestre"));
		                        row.append( $('<td>').text(jsonResponse[0][i].semestre));
		                        $("#projectsList").append(row); // agregar renglon a la tabla
		                        $("#projectsList").append($('<tr style="color: black;">').append( $('<td colspan="4">')));
                            });
                        }
                        $("#projectsList").show();
                        $("#findNoMatch").hide();
                    }
                    else if(jsonResponse.status == "NO MATCHES FOUND"){
                        $("#projectsList").hide();
                        $("#findNoMatch").show();
                    }
                },
                error: function(errorMessage){
                    alert(errorMessage.responseText);
                }
            });
        }
        else{
            alert("Filtra Proyectos por Nombre, Clasificación Sectorial o Semestre");
        }
    });

	$("#logoutBtn").on("click", function(){
        var jsonToSend = {
	        "action" : "LOGOUTALUMNO"
	    };

	    $.ajax({
	        url : "data/applicationLayer.php",
	        type : "POST",
	        data : jsonToSend,
	        dataType : "json",
	        contentType : "application/x-www-form-urlencoded",
	        success : function(jsonResponse){
	            window.location.replace("login.html");
	        },
	        error : function(errorMessage){
	            alert(errorMessage.responseText);
	        }
	    });                
    });

    $("#guardarBtn").on("click", function(){
    	if ($("#editNombre").val() != "" && $("#editEmpresa").val() != "" && $("#editDescripcion").val() != ""
    		&& $("#editClasif").val() != "" && $("#editGiro").val() != ""){
    		var jsonToSend = {
    			"action" : "EDITPROJECT",
    			"proyecto" : $("#editMiProyecto").find('tr:eq(0)').find('td:eq(0)').text(),
    			"nombre" : $("#editNombre").val(),
    			"empresa" : $("#editEmpresa").val(),
    			"descripcion" : $("#editDescripcion").val(),
    			"clasificacion" : $("#editClasif").val(),
    			"giro" : $("#editGiro").val()
    		}

    		$.ajax({
		        url : "data/applicationLayer.php",
		        type : "POST",
		        data : jsonToSend,
		        dataType : "json",
		        contentType : "application/x-www-form-urlencoded",
		        success : function(jsonResponse){
		            alert("El Proyecto se ha guardado correctamente!");
		        },
		        error : function(errorMessage){
		            alert(errorMessage.responseText);
		        }
		    }); 
    	}
    	else{
    		alert("Llena todos los campos");
    	}
    });

});

function cargarProyectos()
{
	var jsonToSend = {
        "action" : "LOADPREVIOUSPROJECTS"
    };

    $.ajax({
        url: "data/applicationLayer.php",
        type: "POST",
        data: jsonToSend,
        dataType: "json",
        contentType : "application/x-www-form-urlencoded",
        success: function(jsonResponse){
        	$("#registroProyecto").hide();
        	$("#proyectosPrevios").show();
        	// tabs css
	        $("#menu li > input[type=submit]").css({
	    		'background-color' : '#CCC',
	    		'color' : '#003399'
	    	});
	        $("#proyectosBtn").css({
	    		'background-color' : '#999',
	    		'color' : 'white'
	    	});
            if(jsonResponse.status == "SUCCESS"){
                $("#projectsList tr").remove();
                for (var i = 0; i <= jsonResponse[0].length; i++) {
                    $(jsonResponse[0][i]).each(function(){
                        var row = $("<tr>"); 
                        row.append($("<th>").text("Nombre del Proyecto"));
                        row.append( $("<td>").text(jsonResponse[0][i].nombre));
                        row.append( $("<th>").text("Descripcion del Negocio"));
                        row.append( $("<th>").text("Giro del negocio"));
                        $("#projectsList").append(row); 
                        row = $("<tr>"); //  crear nuevo renglon
                        row.append( $("<th>").text("Empresa"));
                        row.append( $('<td>').text(jsonResponse[0][i].empresa));
                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].descripcion));
                        row.append( $('<td rowspan="3">').text(jsonResponse[0][i].giro));
                        $("#projectsList").append(row); // agregar renglon a la tabla
                        row = $("<tr>"); //  crear nuevo renglon
                        row.append( $("<th>").text("Clasificacion Sectorial"));
                        row.append( $('<td>').text(jsonResponse[0][i].clasificacion));
			        	$("#projectsList").append(row); // agregar renglon a la tabla
                        row = $("<tr>"); //  crear nuevo renglon
                        row.append( $("<th>").text("Semestre"));
                        row.append( $('<td>').text(jsonResponse[0][i].semestre));
                        $("#projectsList").append(row); // agregar renglon a la tabla
                        $("#projectsList").append($('<tr style="color: black;">').append( $('<td colspan="4">')));
                    });
                }
                $("#projectsList").show();
                $("#findNoMatch").hide();
            }
            else if(jsonResponse.status == "NO MATCHES FOUND"){
                $("#projectsList").hide();
                $("#findNoMatch").show();
            }
        },
        error: function(errorMessage){
            alert(errorMessage.responseText);
        }
    });
}

function checkAlumno()
{
	var jsonToSend = {
        "action" : "CHECKALUMNO"
    };
    $.ajax({
        url : "data/applicationLayer.php",
        type : "POST",
        data : jsonToSend,
        dataType : "json",
        contentType : "application/x-www-form-urlencoded",
        success : function(jsonResponse){
            if (jsonResponse.status == "SUCCESS"){
            	$("#miProyectoBtn").show();
            	$("#nuevoProyectoBtn").hide();
                var row = $('<tr style="display: none;">'); // crear renglon en la tabla
                row.append( $("<td>").text(jsonResponse[0].proyectoId));
                $("#editMiProyecto").append(row); // agregar renglon a la tabla
                row = $("<tr>"); //  crear nuevo renglon
                row.append($("<th>").text("Nombre del Proyecto"));
                row.append( $("<td>").append($('<input id="editNombre" type="text">').val(jsonResponse[0].nombre)));
                row.append( $("<th>").text("Descripcion del Negocio"));
                $("#editMiProyecto").append(row); // agregar renglon a la tabla
                row = $("<tr>"); //  crear nuevo renglon
                row.append( $("<th>").text("Empresa"));
                row.append( $('<td>').append($('<input id="editEmpresa" type="text">').val(jsonResponse[0].empresa)));
                row.append( $('<td rowspan="4">').append($('<textarea id="editDescripcion" cols="60" rows="8">').text(jsonResponse[0].descripcion)));
                $("#editMiProyecto").append(row); // agregar renglon a la tabla
                row = $("<tr>"); //  crear nuevo renglon
                row.append( $("<th>").text("Clasificacion Sectorial"));
                row.append( $('<td>').append($('<input id="editClasif" type="text">').val(jsonResponse[0].clasificacion)));
                $("#editMiProyecto").append(row); // agregar renglon a la tabla
                row = $("<tr>"); //  crear nuevo renglon
                row.append( $("<th>").text("Giro del negocio"));
                row.append( $('<td>').append($('<input id="editGiro" type="text">').val(jsonResponse[0].giro)));
	        	$("#editMiProyecto").append(row); // agregar renglon a la tabla

	        	// comentarios del profesor
			    if (jsonResponse[0].comentario != ""){
			    	$("#feedback").append($('<tr>').append($('<td>').text(jsonResponse[0].comentario)));
			    	$("#noFeedback").hide();
			    }
			    else {
			    	$("#feedback").hide();
			    	$("#noFeedback").show();
			    }
            }
        },
        error : function(errorMessage){
            alert(errorMessage.responseText);
        }
    });  
}