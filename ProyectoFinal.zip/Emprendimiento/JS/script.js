$(document).ready(function(){

	$("#alumnoBtn").on("click", function(){
		$("#loginAlumnos").show();
		$("#loginMaestros").hide();
	});

	$("#profeBtn").on("click", function(){
		$("#loginAlumnos").hide();
		$("#loginMaestros").show();
	});

	$("#loginAlumnoBtn").on("click", function(){

		var jsonToSend = {
			"action" : "LOGINALUMNOS",
			"alumnoId" : $("#alumnoId").val(),
			"password" : $("#alumnoPassword").val()
		};

		$.ajax({
	        url : "data/applicationLayer.php",
	        type : "POST",
	        data : jsonToSend,
	        dataType : "json",
	        contentType : "application/x-www-form-urlencoded",
	        success : function(jsonResponse){
	            window.location.replace("sitioAlumnos.html");
	        },
	        error : function(errorMessage){
	            alert(errorMessage.responseText);
	        }
	    });
	});

	$("#loginProfeBtn").on("click", function(){

		var jsonToSend = {
			"action" : "LOGINPROFE",
			"profeId" : $("#profeId").val(),
			"password" : $("#profePassword").val()
		};

		$.ajax({
	        url : "data/applicationLayer.php",
	        type : "POST",
	        data : jsonToSend,
	        dataType : "json",
	        contentType : "application/x-www-form-urlencoded",
	        success : function(jsonResponse){
	            window.location.replace("sitioMaestros.html");
	        },
	        error : function(errorMessage){
	            alert(errorMessage.responseText);
	        }
	    });
	});

	// LOGIN ADMIN
    $("#loginBtn").on("click", function(){
        var jsonToSend = {
            "action" : "LOGINADMIN",
            "adminId" : $("#userId").val(),
            "password" : $("#userPassword").val(),
            "rememberMe" : $("#rememberMe").is(":checked")
        };

        $.ajax({
	        url : "data/applicationLayer.php",
	        type : "POST",
	        data : jsonToSend,
	        dataType : "json",
	        contentType : "application/x-www-form-urlencoded",
	        success : function(jsonResponse){
	            window.location.replace("sitioAdmin.html");
	        },
	        error : function(errorMessage){
	            alert(errorMessage.responseText);
	        }
	    });
    });

});