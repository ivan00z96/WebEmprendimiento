$(document).ready(function(){
	$("#gruposBtn").on("click", function(){
		var jsonToSend = {
            "action" : "LOADGROUPS"
        }
        $.ajax({
            url : "data/applicationLayer.php",
            type : "POST",
            data : jsonToSend,
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success: function(jsonResponse){
            	$("#proyectosGrupo").hide();
            	$("#revisionProyecto").hide();
            	$("#grupoNumBtn").hide();
            	$("#grupos").show();
            	// tabs css
	            $("#menu li > input[type=submit]").css({
	        		'background-color' : '#CCC',
	        		'color' : '#003399'
	        	});
	            $("#gruposBtn").css({
	        		'background-color' : '#999',
	        		'color' : 'white'
	        	});
                if(jsonResponse.status == "SUCCESS"){
                    $("#groupList tr td").remove();
                    for (var i = 0; i <= jsonResponse[0].length; i++) {
                        $(jsonResponse[0][i]).each(function(){
                            var row = $("<tr>");
                            row.append( $('<td class="cellButton">').text("Grupo " + jsonResponse[0][i].numGrupo));
                            row.append( $('<td style="display: none;">').text(jsonResponse[0][i].idGrupo));
                            //row.append( $('<td class="cellButton">').append($('<input class="cellBtn" type="submit" value="Send Request">')) );
                            $("#groupList").append(row);
                        });
                    }
                    $("#groupList").show();
                    $("#noGroups").hide();
                }
                else if(jsonResponse.status == "NO MATCHES FOUND"){
                    $("#groupList").hide();
                    $("#noGroups").show();
                }
            },
            error: function(errorMessage){
                alert(errorMessage.responseText);
            }
        });
	});

	$('body').delegate('.cellButton', 'click', function(){
        var groupId = $(this).parent().find('td:eq(1)').text();
        var num = $(this).parent().find('td:eq(0)').text();
        var jsonToSend = {
            "action" : "LOADGROUPPROJECTS",
            "groupId" : groupId
        }
        $.ajax({
            url : "data/applicationLayer.php",
            type : "POST",
            data : jsonToSend,
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success : function(jsonResponse){
            	$("#grupos").hide();
            	$("#revisionProyecto").hide();
            	$("#proyectosGrupo").show();
            	$("#grupoNumBtn").val(num);
                $("#grupoNumBtn").show();

            	// tabs css
	            $("#menu li > input[type=submit]").css({
	        		'background-color' : '#CCC',
	        		'color' : '#003399'
	        	});
	            $("#grupoNumBtn").css({
	        		'background-color' : '#999',
	        		'color' : 'white'
	        	});

                if(jsonResponse.status == "SUCCESS"){
                    $("#projectsList tr td").remove(); //remove data table rows
                    $("#projectsList tr select").remove();
                    for (var i = 0; i <= jsonResponse[0].length; i++) {
                        $(jsonResponse[0][i]).each(function(){
                            var row = $("<tr>");
                            row.append( $('<td class="cellProject">').text(jsonResponse[0][i].nombre));
                            row.append( $('<td>').text(jsonResponse[0][i].rank));
                            row.append( $('<td style="display: none;">').text(jsonResponse[0][i].id));
                            var checkApto = $('<select class="apto">');
                            checkApto.append($('<option>', {
							    value: 'SI',
							    text: 'SI'
							}));
							checkApto.append($('<option>', {
							    value: 'NO',
							    text: 'NO'
							}));
                            checkApto.val(jsonResponse[0][i].apto);
                            row.append(checkApto);
                            //row.append( $('<td class="cellButton">').append($('<input class="cellBtn" type="submit" value="Send Request">')) );
                            $("#projectsList").append(row);
                        });
                    }
                    
                    $("#projectsList").show();
                    
                    $("#noProjects").hide();
                }
                else if(jsonResponse.status == "NO MATCHES FOUND"){
                    $("#projectsList").hide();
                    $("#noProjects").show();
                }
            },
            error : function(errorMessage){
                alert(errorMessage.responseText);
            }
        });
    });

    $('body').delegate('.cellProject', 'click', function(){
    	var projectId = $(this).parent().find('td:eq(2)').text();
    	var jsonToSend = {
            "action" : "REVIEWPROJECT",
            "project" : projectId
        }
        $.ajax({
	        url : "data/applicationLayer.php",
	        type : "POST",
	        data : jsonToSend,
	        dataType : "json",
	        contentType : "application/x-www-form-urlencoded",
	        success : function(jsonResponse){

	        	$("#singleProject tr").remove();

                var row = $('<tr style="display: none;">'); // crear renglon en la tabla
                row.append( $("<td>").text(jsonResponse[0].proyectoId));
                $("#singleProject").append(row); 
                row = $("<tr>"); 
                row.append($("<th>").text("Nombre del Proyecto"));
                row.append( $("<td>").text(jsonResponse[0].nombre));
                row.append( $("<th>").text("Descripcion del Negocio"));
                row.append( $("<th>").text("Giro del negocio"));
                $("#singleProject").append(row); 
                row = $("<tr>"); //  crear nuevo renglon
                row.append( $("<th>").text("Empresa"));
                row.append( $('<td>').text(jsonResponse[0].empresa));
                row.append( $('<td rowspan="2">').text(jsonResponse[0].descripcion));
                row.append( $('<td rowspan="2">').text(jsonResponse[0].giro));
                $("#singleProject").append(row); // agregar renglon a la tabla
                row = $("<tr>"); //  crear nuevo renglon
                row.append( $("<th>").text("Clasificacion Sectorial"));
                row.append( $('<td>').text(jsonResponse[0].clasificacion));
	        	$("#singleProject").append(row); // agregar renglon a la tabla
	            
	            $("#proyectoBtn").val(jsonResponse[0].nombre);
	            $("#proyectoBtn").show();

	            // tabs css
	            $("#menu li > input[type=submit]").css({
	        		'background-color' : '#CCC',
	        		'color' : '#003399'
	        	});
	            $("#proyectoBtn").css({
	        		'background-color' : '#999',
	        		'color' : 'white'
	        	});

	            $("#revisionProyecto").show();
	            $("#proyectosGrupo").hide();
	        },
	        error : function(errorMessage){
	            alert(errorMessage.responseText);
	        }
	    });
    });

    $("#grupoNumBtn").on("click", function(){
    	// tabs css
        $("#menu li > input[type=submit]").css({
    		'background-color' : '#CCC',
    		'color' : '#003399'
    	});
        $("#grupoNumBtn").css({
    		'background-color' : '#999',
    		'color' : 'white'
    	});

    	$("#proyectosGrupo").show();
    	$("#proyectoBtn").hide();
    	$("#revisionProyecto").hide();
    });

    $("#projectsList tbody").sortable({
		axis: 'y',
		update: function(){
			$("#projectsList tbody tr").each(function(project){
				if($(this).index() != 0){
					$(this).find('td:eq(1)').text($(this).index());
				}
			});
		}
	});

	$("#guardarBtn").on("click", function(){
		var idA = [];
		var pNombreA = [];
		var rankA = [];
		var aptoA = [];
		$("#projectsList tbody tr").each(function(project){
			if($(this).index() != 0){
				pNombreA.push($(this).find('td:eq(0)').text());
				rankA.push($(this).find('td:eq(1)').text());
				idA.push($(this).find('td:eq(2)').text());
				aptoA.push($(this).find('select :selected').val());
			}
		});
		for(var i = 0; i < aptoA.length; i++){
			if (aptoA[i] == "SI"){
				aptoA[i] = 1;
			}
			else{
				aptoA[i] = 0;
			}
		}
		var jsonToSend = {
			"action" : "PROFESAVEPROJECTS",
			"idA" : idA,
			"pNombreA" : pNombreA,
			"rankA" : rankA,
			"aptoA" : aptoA
		}
		$.ajax({
            url : "data/applicationLayer.php",
            type : "POST",
            data : jsonToSend,
            dataType : "json",
            contentType : "application/x-www-form-urlencoded",
            success : function(jsonResponse){
            	alert("success");
            },
            error : function(errorMessage){
                alert(errorMessage.responseText);
            }
        });
	});

	// AGREGAR COMENTARIOS A PROYECTO
    $("#enviarComentarioBtn").on("click", function(){
    	var projectId = $("#singleProject").find('tr:eq(0)').find('td:eq(0)').text();
        var $newComment = $("#feedback");
        if ($newComment.val() == ""){
            alert("No ha escrito comentarios");
        } else {

            var jsonToSend = {
                "action" : "FEEDBACKPROJECT",
                "project" : projectId,
                "cText" : $newComment.val()
            };

            $.ajax({
                url : "data/applicationLayer.php",
                type : "POST",
                data : jsonToSend,
                dataType : "json",
                contentType : "application/x-www-form-urlencoded",
                success : function(jsonResponse){
                    alert(jsonResponse.message);
                    $("#feedback").val("");
                },
                error : function(errorMessage){
                    alert(errorMessage.responseText);
                }
            });
        }
    });

    $("#homeBtn").on("click", function(){
    	// tabs css
        $("#menu li > input[type=submit]").css({
    		'background-color' : '#CCC',
    		'color' : '#003399'
    	});
        $("#homeBtn").css({
    		'background-color' : '#999',
    		'color' : 'white'
    	});

    	// actualizar vista
    	$("#proyectoBtn").hide();
    	$("#revisionProyecto").hide();
    	$("#proyectosGrupo").hide();
    	$("#grupoNumBtn").hide();
    	$("#grupos").hide();
    });

	$("#logoutBtn").on("click", function(){
        var jsonToSend = {
	        "action" : "LOGOUTPROFE"
	    };

	    $.ajax({
	        url : "data/applicationLayer.php",
	        type : "POST",
	        data : jsonToSend,
	        dataType : "json",
	        contentType : "application/x-www-form-urlencoded",
	        success : function(jsonResponse){
	            window.location.replace("login.html");
	        },
	        error : function(errorMessage){
	            alert(errorMessage.responseText);
	        }
	    });                
    });

});