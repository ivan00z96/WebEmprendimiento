<?php

function connectionToDataBase(){
	$servername = "localhost";
	$username = "root";
	$password = "root";
	$dbname = "emprendimiento";

	$conn = new mysqli($servername, $username, $password, $dbname);
	
	
	if ($conn->connect_error){
		return null;
	}
	else{
		return $conn;
	}
}

// -------------------------------- PROFESOR ------------------------------------------

function attemptLoginProfe($profeId, $password)
{
	$conn = connectionToDataBase();

	if ($conn != null){
		$sql = "SELECT * FROM Profesor WHERE profesorId = '$profeId' AND passwrd = '$password'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			// session
            session_start();
            session_destroy();
            session_start();

            $row = $result->fetch_assoc();
            $_SESSION["profeId"] = $row['profesorId'];
            $_SESSION["nombre"] = $row['nombre'];

			$conn -> close();
			return array('status' => 'SUCCESS');
		}
		else{
			$conn -> close();
			return array("status" => "WRONG CREDENTIALS PROVIDED");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptLoadGroups($profesor)
{
	$conn = connectionToDataBase();

	if ($conn != null){
		
		$sql = "SELECT * FROM Grupos WHERE profesor = '$profesor'";
		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			$resp = array();
			$response = array("status" => "SUCCESS");
			// output data of each row
		    while($row = $result->fetch_assoc()) 
		    {
		    	$aux = array('numGrupo' => $row['numGrupo'], "idGrupo" => $row["grupoId"]);
		    	array_push($resp, $aux);     
			}
			array_push($response, $resp);
			$conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO COMMENTS FOUND");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptLoadGroupProjects($grupo)
{
	$conn = connectionToDataBase();

	if ($conn != null){
		$sql = "SELECT DISTINCT p.proyectoId, p.nombre, p.apto, p.rank FROM Proyectos p, Grupos g, Alumnos a 
		WHERE g.grupoId = '$grupo' AND a.grupo = '$grupo' AND p.proyectoId = a.proyecto ORDER BY p.rank";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			$resp = array();
			$response = array("status" => "SUCCESS");
			// output data of each row
		    while($row = $result->fetch_assoc()) 
		    {
		    	$aux = array('nombre' => $row['nombre'], 'id' => $row['proyectoId'], 'apto' => $row['apto'], "rank" => $row["rank"]);
		    	if ($aux["apto"] == 0){
		    		$aux['apto'] = "NO";
		    	}
		    	else{
		    		$aux['apto'] = "SI";
		    	}
		    	array_push($resp, $aux);     
			}
			array_push($response, $resp);
			$conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptProfeSaveProjects($idA, $pNombreA, $rankA, $aptoA)
{
	$conn = connectionToDataBase();

	if ($conn != null){
		$i = 0;
		$error = false;
		while ($i <= count($idA) - 1 && !$error) {
			$sql = "UPDATE Proyectos SET rank = '$rankA[$i]', apto = '$aptoA[$i]' WHERE proyectoId = '$idA[$i]'";
			if (mysqli_query($conn, $sql) == false){
				$error = true;
			}
			$i += 1; 
		}
		if (!$error){
			$conn -> close();
    		return array("status" => "SUCCESS");
		}
		else{
			$conn -> close();
			return array("status" => "BADCONN UPDATE");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptReviewProject($project)
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "SELECT * FROM Proyectos WHERE proyectoId = '$project'";

		$result = $conn->query($sql);

		if ($result->num_rows == 1)
		{
			// output data
		    $row = $result->fetch_assoc();

		    // prepare answer 
		    $response = array("status" => "SUCCESS");
		    $resp = array('proyectoId' => $row['proyectoId'], 'nombre' => utf8_encode($row['nombre']), 'empresa' => utf8_encode($row['empresa']),
		    	'descripcion' => utf8_encode($row['descripcion']),'clasificacion' => utf8_encode($row['clasificacionSectorial']),
		    	'giro' => utf8_encode($row['giro']));   
			
		    array_push($response, $resp);
		    $conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else
	{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptFeedbackProject($project, $cText)
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "UPDATE Proyectos SET comentarios = '$cText' WHERE proyectoId = '$project'";

		if (mysqli_query($conn, $sql)) 
    	{
		    $conn -> close();
		    return array("status" => "SUCCESS", "message" => "Comentarios enviados");
		} 
		else 
		{
			$conn -> close();
			return array("status" => "BADCONN");
		}
	}
	else
	{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

// --------------------------------------- ALUMNO --------------------------------

function attemptLoginAlumno($alumnoId, $password)
{
	$conn = connectionToDataBase();

	if ($conn != null){
		$sql = "SELECT * FROM Alumnos WHERE alumnoId = '$alumnoId' AND passwrd = '$password'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			// session
            session_start();
            session_destroy();
            session_start();

            $row = $result->fetch_assoc();
            $_SESSION["alumnoId"] = $row['alumnoId'];
            $_SESSION["nombre"] = $row['nombre'];
            $_SESSION["carrera"] = $row['carrera'];
            $_SESSION["email"] = $row['emailPersonal'];
            $_SESSION["grupo"] = $row['grupo'];

			$conn -> close();
			return array('status' => 'SUCCESS');
		}
		else{
			$conn -> close();
			return array("status" => "WRONG CREDENTIALS PROVIDED");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptLoadPreviousProjects()
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "SELECT * FROM ProyectosPrevios";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			$resp = array();
			$response = array("status" => "SUCCESS");
			// output data of each row
		    while($row = $result->fetch_assoc()) 
		    {
		    	$aux = array('nombre' => utf8_encode($row['nombre']), 'empresa' => utf8_encode($row['empresa']), 'descripcion' => utf8_encode($row['descripcion']),
		    		'clasificacion' => utf8_encode($row['clasificacionSectorial']), 'giro' => utf8_encode($row['giro']), 'semestre' => $row['semestre']);
		    	array_push($resp, $aux);     
			}
			array_push($response, $resp);
			$conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptRegisterProject($grupo, $nombre, $empresa, $descripcion, $clasificacion, $giro, $integrantes, $nombreA, $matriculaA, $carreraA, $emailAcademicoA,
	$emailPersonalA, $celularA)
{
	$conn = connectionToDataBase();

	if ($conn != null){
		$i = 0;
		$error = false;
		while ($i <= $integrantes - 1 && !$error) {
			$sql = "INSERT IGNORE INTO Alumnos (alumnoId, nombre, carrera, passwrd, emailAcademico, emailPersonal, celular, grupo) VALUES 
			('$matriculaA[$i]', '$nombreA[$i]', '$carreraA[$i]', '$matriculaA[$i]', '$emailAcademicoA[$i]', '$emailPersonalA[$i]', '$celularA[$i]', '$grupo')";

			if (mysqli_query($conn, $sql) == false){
				$error = true;
			}
			$i += 1; 
		}
		if ($error){
			$conn -> close();
			return array("status" => "BADCONN INSERT Alumnos");
		}
		else{
			$sql ="INSERT INTO Proyectos (nombre, empresa, descripcion, clasificacionSectorial, giro, semestre)
			VALUES ('$nombre', '$empresa', '$descripcion', '$clasificacion', '$giro', 'EM-17')";
			if (mysqli_query($conn, $sql)){
				$id = mysqli_insert_id($conn);
				$i = 0;
				$error = false;
				while ($i <= $integrantes - 1 && !$error) {
					$sql = "UPDATE Alumnos SET proyecto = '$id' WHERE alumnoId = '$matriculaA[$i]'";
					if (mysqli_query($conn, $sql) == false){
						$error = true;
					}
					$i += 1; 
				}
				if (!$error){
					$conn -> close();
		    		return array("status" => "SUCCESS", 'proyectoId' => $id);
				}
				else{
					$conn -> close();
					return array("status" => "BADCONN UPDATE");
				}
			}
			else{
				$conn -> close();
				return array("status" => "BADCONN INSERT");
			}
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptLoadMyProject($alumno)
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "SELECT Proyectos.* FROM Proyectos, Alumnos WHERE alumnoId = '$alumno' AND proyecto = proyectoId";
		$result = $conn->query($sql);

		if ($result->num_rows == 1)
		{
			// output data of each row
		    $row = $result->fetch_assoc();

		    // prepare answer 
		    $response = array("status" => "SUCCESS");
		    $resp = array('proyectoId' => $row['proyectoId'], 'nombre' => utf8_encode($row['nombre']), 'empresa' => utf8_encode($row['empresa']),
		    	'descripcion' => utf8_encode($row['descripcion']),'clasificacion' => utf8_encode($row['clasificacionSectorial']),
		    	'giro' => utf8_encode($row['giro']), 'comentario' => utf8_encode($row['comentarios']));   
			
		    array_push($response, $resp);
		    $conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else
	{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptSearchProjects($search)
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "SELECT * FROM ProyectosPrevios WHERE nombre LIKE '%$search%' OR clasificacionSectorial LIKE '%$search%' OR empresa LIKE '%$search%' OR semestre LIKE '%$search%'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			$resp = array();
			$response = array("status" => "SUCCESS");
			// output data of each row
		    while($row = $result->fetch_assoc()) 
		    {
		    	$aux = array('nombre' => utf8_encode($row['nombre']), 'empresa' => utf8_encode($row['empresa']), 'descripcion' => utf8_encode($row['descripcion']),
		    		'clasificacion' => utf8_encode($row['clasificacionSectorial']), 'giro' => utf8_encode($row['giro']), 'semestre' => $row['semestre']);
		    	array_push($resp, $aux);     
			}
			array_push($response, $resp);
			$conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptEditProject($proyecto, $nombre, $empresa, $descripcion, $clasificacion, $giro)
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		//$clasificacion = utf8_decode($clasificacion);
		$sql = "UPDATE Proyectos SET nombre = '$nombre', empresa = '$empresa', descripcion = '$descripcion',
		clasificacionSectorial = '$clasificacion', giro = '$giro' WHERE proyectoId = '$proyecto'";

		if (mysqli_query($conn, $sql)) 
    	{
		    $conn -> close();
		    return array("status" => "SUCCESS");
		} 
		else 
		{
			$conn -> close();
			return array("status" => "BADCONN");
		}
	}
	else
	{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

// ------------------------------------FIN ALUMNO ----------------------------------

// --------------------------------- ADMIN -----------------------------------------

function attemptLoginAdmin($adminId, $password)
{
	$conn = connectionToDataBase();

	if ($conn != null){
		$sql = "SELECT * FROM Administrador WHERE adminId = '$adminId' AND passwrd = '$password'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			// session
            session_start();
            session_destroy();
            session_start();

            $row = $result->fetch_assoc();
            $_SESSION["adminId"] = $row['adminId'];
            $_SESSION["nombre"] = $row['nombreCompleto'];

			$conn -> close();
			return array('status' => 'SUCCESS');
		}
		else{
			$conn -> close();
			return array("status" => "WRONG CREDENTIALS PROVIDED");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptLoadProjectsAdmin()
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "SELECT DISTINCT p.*, g.numGrupo, r.nombre AS 'profesor' FROM Proyectos p, Grupos g, Alumnos a, profesor r WHERE g.grupoId = a.grupo AND p.proyectoId = a.proyecto AND r.profesorId = g.profesor ORDER BY 'profesor'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			$resp = array();
			$response = array("status" => "SUCCESS");
			// output data of each row
		    while($row = $result->fetch_assoc()) 
		    {
		    	$aux = array('nombre' => utf8_encode($row['nombre']), 'empresa' => utf8_encode($row['empresa']), 'descripcion' => utf8_encode($row['descripcion']),
		    		'clasificacion' => utf8_encode($row['clasificacionSectorial']), 'giro' => utf8_encode($row['giro']),
		    		'profesor' => utf8_encode($row['profesor']), 'grupo' => $row['numGrupo'], 'apto' => $row['apto'], "rank" => $row["rank"]);

		    	if ($aux["apto"] == 0){
		    		$aux['apto'] = "NO";
		    	}
		    	else{
		    		$aux['apto'] = "SI";
		    	}

		    	array_push($resp, $aux);     
			}
			array_push($response, $resp);
			$conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptSearchProjectsAdmin($search)
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "SELECT DISTINCT p.*, g.numGrupo, r.nombre AS 'profesor' FROM Proyectos p, Grupos g, Alumnos a, profesor r WHERE (g.grupoId = a.grupo AND p.proyectoId = a.proyecto AND r.profesorId = g.profesor) AND (p.nombre LIKE '%$search%' OR p.clasificacionSectorial LIKE '%$search%'
			OR p.empresa LIKE '%$search%' OR r.nombre LIKE '%$search%') ORDER BY 'profesor'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			$resp = array();
			$response = array("status" => "SUCCESS");
			// output data of each row
		    while($row = $result->fetch_assoc()) 
		    {
		    	$aux = array('nombre' => utf8_encode($row['nombre']), 'empresa' => utf8_encode($row['empresa']), 'descripcion' => utf8_encode($row['descripcion']),
		    		'clasificacion' => utf8_encode($row['clasificacionSectorial']), 'giro' => utf8_encode($row['giro']),
		    		'profesor' => utf8_encode($row['profesor']), 'grupo' => $row['numGrupo'], 'apto' => $row['apto'], "rank" => $row["rank"]);

		    	if ($aux["apto"] == 0){
		    		$aux['apto'] = "NO";
		    	}
		    	else{
		    		$aux['apto'] = "SI";
		    	}

		    	array_push($resp, $aux);     
			}
			array_push($response, $resp);
			$conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

function attemptGenerarLista()
{
	$conn = connectionToDataBase();

	if ($conn != null)
	{
		$sql = "SELECT DISTINCT p.*, g.numGrupo, r.nombre AS 'profesor' FROM Proyectos p, Grupos g, Alumnos a, profesor r WHERE g.grupoId = a.grupo AND p.proyectoId = a.proyecto AND r.profesorId = g.profesor ORDER BY 'profesor'";

		$result = $conn->query($sql);

		if ($result->num_rows > 0)
		{
			$resp = array();
			$response = array("status" => "SUCCESS");
			// output data of each row
		    while($row = $result->fetch_assoc()) 
		    {
		    	$aux = array('nombre' => utf8_encode($row['nombre']), 'empresa' => utf8_encode($row['empresa']), 'descripcion' => utf8_encode($row['descripcion']),
		    		'clasificacion' => utf8_encode($row['clasificacionSectorial']), 'giro' => utf8_encode($row['giro']),
		    		'profesor' => utf8_encode($row['profesor']), 'grupo' => $row['numGrupo'], 'apto' => $row['apto'], "rank" => $row["rank"]);

		    	if ($aux["apto"] == 0){
		    		$aux['apto'] = "NO";
		    	}
		    	else{
		    		$aux['apto'] = "SI";
		    	}

		    	// llenar cantidad
		    	if ($aux['grupo']){}

		    	array_push($resp, $aux);     
			}

			$cantEnGrupos = array();
			$cantidad = 1;
			$t = count($resp);
			$i = 1;

			while ($i < $t) {
				if ($resp[$i]['profesor'] != $resp[$i-1]['profesor'] || $resp[$i]['grupo'] != $resp[$i-1]['grupo']){
					array_push($cantEnGrupos, $cantidad);
					$cantidad = 1;
				}
				else {
					$cantidad++;
				}
				$i++;
			}
			array_push($cantEnGrupos, $cantidad);

			$cantGrupos = count($cantEnGrupos);
			$j = 0;
			$i = 0;
			$seleccionados = array();

			while ($j < $cantGrupos) {
				$k = 0;
				$lim = $cantEnGrupos[$j];

				while ($k <= $lim) {
					if ($resp[$i]['apto'] == 'SI' && $resp[$i]['rank'] <= round(($lim / 2), 0, PHP_ROUND_HALF_UP)){
						array_push($seleccionados, $resp[$i]);
					}
					$i++;
					$k++;
				}
				$j++;
			}
			

			array_push($response, $seleccionados);
			$conn -> close();
		    return $response;
		}
		else
		{
	    	$conn -> close();
			return array("status" => "NO MATCHES FOUND");
		}
	}
	else{
		$conn -> close();
		return array("status" => "CONNECTION WITH DB WENT WRONG");
	}
}

?>
