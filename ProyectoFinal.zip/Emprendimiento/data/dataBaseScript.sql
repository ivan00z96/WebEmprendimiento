CREATE TABLE Profesor (
	profesorId VARCHAR(10) NOT NULL PRIMARY KEY,
	nombre VARCHAR(50) NOT NULL,
	apellido VARCHAR(50) NOT NULL,
	passwrd VARCHAR(50) NOT NULL,
	jerarquía INT 
);

CREATE TABLE Grupos (
	grupoId INT NOT NULL AUTO_INCREMENT,
	numGrupo INT NOT NULL,
	profesor VARCHAR(10),
	PRIMARY KEY (grupoId),
	FOREIGN KEY (profesor)
        REFERENCES Profesor(profesorId)
        ON DELETE CASCADE
);

CREATE TABLE Proyectos (
	proyectoId INT NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(50) NOT NULL,
	empresa VARCHAR(50) NOT NULL,
	descripcion VARCHAR(600) NOT NULL,
	clasificacionSectorial VARCHAR(50) NOT NULL,
	giro VARCHAR(200) NOT NULL,
	semestre CHAR(6) NOT NULL,
	apto INT,
	rank INT,
	PRIMARY KEY (proyectoId)
);

CREATE TABLE Alumnos (
	alumnoId VARCHAR(10) NOT NULL PRIMARY KEY,
	nombre VARCHAR(60) NOT NULL,
    carrera CHAR(5) NOT NULL,
    passwrd VARCHAR(50) NOT NULL,
    emailAcademico VARCHAR(30) NOT NULL,
    emailPersonal VARCHAR(30) NOT NULL,
    celular VARCHAR(20),
    grupo VARCHAR(30), 
    proyecto VARCHAR(30),
    FOREIGN KEY (grupo)
        REFERENCES Grupos(grupoId)
        ON DELETE CASCADE,
    FOREIGN KEY (proyecto)
        REFERENCES Proyectos(proyectoId)
        ON DELETE CASCADE
);

CREATE TABLE ProyectosPrevios (
	id MEDIUMINT NOT NULL AUTO_INCREMENT,
	nombre VARCHAR(50) NOT NULL,
	empresa VARCHAR(50) NOT NULL,
	descripcion VARCHAR(600) NOT NULL,
	clasificacionSectorial VARCHAR(50) NOT NULL,
	giro VARCHAR(200) NOT NULL,
	semestre VARCHAR(6) NOT NULL,
	PRIMARY KEY (id)
);

CREATE TABLE Administrador (
	adminId VARCHAR(10) NOT NULL PRIMARY KEY,
	nombreCompleto VARCHAR(100) NOT NULL,
	passwrd VARCHAR(50) NOT NULL,
	email VARCHAR(50) NOT NULL
);

INSERT INTO Administrador (adminId, nombreCompleto, passwrd, email)
VALUES ('admin1', 'Edgar Williams Garcia Sosa', 'admin1', 'correo@mail');

INSERT INTO Alumnos (nombre, alumnoId, carrera, passwrd, emailAcademico, emailPersonal, celular)
VALUES ("Ivan Alejandro Leal Cervantes", 'A00815154', 'ITC', 'ivan54', 'a00815154@itesm.mx', 'ivan@mail.com', '81166666');

INSERT INTO ProyectosPrevios (nombre, empresa, descripcion, clasificacionSectorial, giro, semestre)
VALUES ("Museo Interactivo A Day in the Future", "A Day in the Future",
'El museo interactivo “A Day in the Future” pretenderá atender la necesidad y el problema de falta de educación en México de manera que incentive a los niños y jóvenes a relacionarse en áreas con tendencias globales y que los adultos tengan una apreciación de éstas. El museo, con un diseño arquitectónico futurista, operará específicamente en Monterrey y su área metropolitana dentro del sector educativo y de recreación pues en éste se expondrán tendencias y futuros desarrollos en áreas como la biotecnología, medicina, biomedicina, mecatrónica, aeroespacial, nanotecnología y ciencias ambientales. Contará con espacios al aire libre, 1 área de comidas y 7 salas temáticas y especializadas para cada área mencionada, las cuales estarán equipadas con material didáctico y vanguardista. Para cada sala habrá un video introductorio del tema, una línea del tiempo, personal capacitado, exposiciones interactivas para todas las edades y diferentes talleres con horarios para niños y jóvenes. Esto con el propósito de educar de forma divertida y atractiva a niños, jóvenes y adultos sobre lo que se espera para el futuro.',
"EDUCACIÓN", "Empresa que busca educar a las futuras generaciones de forma interactiva y actualizada, 
enfoque en las áreas del conocimiento más relevantes para el futuro.", "EM-15"),
('YACANA - TOURS Y tú, ¿a dónde quieres ir hoy?', 'YACANA - TOURS',
'Yakana Tours es una empresa dedicada a ofrecer tours personalizados en autobús en la ciudad de Monterrey y la zona metropolitana, de modo que la empresa se adapta a las necesidades de horario y e intereses del cliente. Una segunda y tercera etapa de crecimiento consisten en desarrollar una aplicación que permita conocer información del servicio, calendario de eventos, reservaciones y pagos en línea, así como ofrecer un servicio de tours predefinidos que circulen continuamente en un horario y días específicos.',
"TRANSPORTE", 'Empresa dedicada al giro de los servicios, ofreciendo tours en autobús para los usuarios que deseen conocer Monterrey y sus alrededores, con el fin de promover el turismo, la cultura y las principales atracciones turísticas en la ciudad.', "EM-15"),
('AUT JACK', 'AUT JACK', 'En esta empresa se elabora el gato eléctrico para tratar de solventar las necesidades de un segmento de la población el cual batallaba mucho cuando necesitaban cambiar los neumáticos del automóvil.',
'AUTOMOTRIZ', 'Industrial', 'EM-15'),
('SMART BUS', 'TECNO BUS', 'SmartBus es un producto que promueve la eficiencia del transporte público',
'ELECTRÓNICA Y COMUNICACIONES', 'Industrial', 'EM-15'),
('Kanan', 'Pimapan-Tibb', 'Desarrollo de productos de detección de infecciones de transmisión sexual innovadores con un bajo costo y un alto grado de confiabilidad, capas de realizarse en cualquier lugar',
'EQUIPO MÉDICO Y PARAMÉDICO', 'Industrial manofacturera y Comercial', 'AD-15'),
('Guantes electrónicos para TKD', 'Tae Tech',
'Guantes de taekwondo con un sistema de puntuación electrónico para taekwondoines que compiten en las diversas justas deportivas que se organizan a nivel local, nacional e internacional. La idea es atender tanto al mercado de comisiones y organizaciones de taekwondo, así como a los pequeños gimnasios y entrenadores que desarrollan a los atletas que compiten en estas competencias.',
'DEPORTIVO Y ELECTRÓNICO', 'Industrial', 'AD-15'),
('Comprando Ando', 'Emprendiendo Andamos',
'Una aplicación móvil llamada “Comprando Ando” que funciona como extensión de los escaparates de las tiendas de un centro comercial para hacer llegar publicidad de sus productos y descuentos a las manos de presuntos consumidores en un tiempo estratégico',
'ELECTRÓNICA Y COMUNICACIONES', 'Servicios', 'AD-15');


INSERT INTO Profesor (profesorId, nombre, passwrd) VALUES ("L00815154", "Edgar Williams Garcia Sosa", "L00815154");

INSERT INTO Grupos (numGrupo, profesor) VALUES ("1", "L00815154"), ("2", "L00815154"), ("3", "L00815154");

INSERT INTO Profesor (profesorId, nombre, passwrd) VALUES ("L00810000", "Doctor Profesor Patricio", "L00810000");

INSERT INTO Grupos (numGrupo, profesor) VALUES ("1", "L00810000"), ("2", "L00810000");

INSERT INTO Proyectos (nombre, empresa, descripcion, clasificacionSectorial, giro)
VALUES ('ElectroMex', 'ElectroMex', 'Electrocardiógrafo de bajo costo para blabbla blablabla bla blablablabla bla blabla blabla blablablabla blablablablabla',
'EQUIPO MÉDICO Y PARAMÉDICO', 'Fabricación y venta de Electrocardiógrafo de bajo costo'),
('U-Suck', 'U-Suck INC', 'Nos dedicamos a apestar en todos los idiomas y sabores aka you suck you really suck holi bye adiós bla bla blablablabla blablabla blabla blabla blablabla blablablabla blablabla bla bla gh hjfjh hjgbjhbg  fdbdfhjfbjhf fhjjhjbjre fhhjf bye',
'JOYERÍA', 'You Suck'),
('Pistorey', 'Pistorey', 'Empresa cervecera dedicada a producir la mejor cerveza del país y del mundo con ingredientes de origen basural y reciclado blabbla blablabla bla blablablabla bla blabla blabla blablablabla blablablablabla',
'MALTA-CERVEZA', 'Venta de pistache')
('Epa', 'ElectroMex', 'Hoal jrjr wachinango adios no leas esto es poro repoio Electrocardiógrafo de bajo costo para blabbla blablabla bla blablablabla bla blabla blabla blablablabla blablablablabla',
'EQUIPO MÉDICO Y PARAMÉDICO', 'Fabricación y venta de Repollo'),
('iSuck', 'iSuck Coporation', 'No se te vaya a ocurrir leer la descripcioj porque encontrará e sjcjk que no siginifica nada relleno repollo y más relleno que una serie que conozco. Nos dedicamos a apestar en todos los idiomas y sabores aka you suck you really suck holi bye adiós bla bla blablablabla blablabla blabla blabla blablabla blablablabla blablabla bla bla gh hjfjh hjgbjhbg  fdbdfhjfbjhf fhjjhjbjre fhhjf bye',
'JOYERÍA', 'Puro Repoio'),
('Pistorico', 'Pistorey P', 'Copia barata de Psitache de pistorey por mirrey, somos una Empresa cervecera dedicada a producir la mejor cerveza del país y del mundo con ingredientes de origen basural y reciclado blabbla blablabla bla blablablabla bla blabla blabla blablablabla blablablablabla',
'MALTA-CERVEZA', 'Repollo de pistache');

INSERT INTO Alumnos (nombre, alumnoId, carrera, passwrd, emailAcademico, emailPersonal, celular)
VALUES ("José María Morelos", 'A00818181', 'ITC', 'ivan54', 'a00818181@itesm.mx', 'josema@mail.com', '81168966'),
("Miguel Hidalgo y Costilla", 'A00817589', 'ITC', 'ivan54', 'a00817589@itesm.mx', 'hidalgo@mail.com', '81168977'),
("Pablo Manuel Garza Flores", 'A00818191', 'LAE', 'ivan54', 'a00818191@itesm.mx', 'pama@mail.com', '81168951'),
("Persona Alumno 1", 'A00000001', 'ABC', 'ivan54', 'emailAcademico1', 'emailPersonal1', '000000001'),
("Persona Alumno 2", 'A00000002', 'ABC', 'ivan54', 'emailAcademico2', 'emailPersonal2', '000000002'),
("Persona Alumno 3", 'A00000003', 'ABC', 'ivan54', 'emailAcademico3', 'emailPersonal3', '000000003');

INSERT INTO Alumnos (nombre, alumnoId, carrera, passwrd, emailAcademico, emailPersonal, celular)
VALUES ("Federico Daniel Leal Cervantes", 'A00815154', 'ITC', 'ivan54', 'a00825154@itesm.mx', 'danLc@mail.com', '81166666');