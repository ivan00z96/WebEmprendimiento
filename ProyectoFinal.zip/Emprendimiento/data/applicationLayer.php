<?php
session_start();
header('Content-type: application/json');
require_once __DIR__ . '/dataLayer.php';

$action = $_POST["action"];

switch($action){
	case "LOGINALUMNOS" : loginAlumnoFunction();
					break;
	case "LOGINPROFE" : loginProfeFunction();
					break;
	case "LOADPREVIOUSPROJECTS": loadPreviousProjects();
					break;
	case "REGISTERPROJECT": registerProject();
					break;
	case "LOADGROUPS": loadGroups();
					break;
	case "LOADGROUPPROJECTS": loadGroupProjects();
					break;
	case "PROFESAVEPROJECTS": profeSaveProjects();
					break;
	case "LOGOUTALUMNO": logoutAlumno();
					break;
	case "LOGOUTPROFE": logoutProfe();
					break;
	case "CHECKALUMNO": checkAlumno();
					break;
	case "SEARCHPROJECTS" : searchProjectsFunction();
					break;
	case "REVIEWPROJECT" : reviewProject();
					break;
	case "FEEDBACKPROJECT" : feedbackProject();
					break;
	case "LOGINADMIN" : loginAdminFunction();
					break;
	case "LOGOUTADMIN": logoutAdmin();
					break;
	case "LOADPROJECTSADMIN" : loadProjectsAdmin();
					break;
	case "SEARCHPROJECTSADMIN" : searchProjectsAdmin();
					break;
	case "EDITPROJECT": editProject();
					break;
	case "GENERARLISTA": generarLista();
					break;
}

// -------------------------------- PROFESOR ------------------------------------------

function loginProfeFunction()
{
	$profeId = $_POST["profeId"];
	$password = $_POST["password"];

	$result = attemptLoginProfe($profeId, $password);

	if ($result["status"] == "SUCCESS"){
		echo json_encode($result);
	}
	else{
		header('HTTP/1.1 500' . $result["status"]);
		die($result["status"]);
	}
}

function loadGroups()
{
	if (isset($_SESSION["profeId"])) {

		$profesor = $_SESSION["profeId"];

		$result = attemptLoadGroups($profesor);

		if ($result["status"] == "SUCCESS"){
			echo json_encode($result);
		}
		else{
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
}

function loadGroupProjects()
{
	if (isset($_SESSION["profeId"])) {

		$grupo = $_POST["groupId"];

		$result = attemptLoadGroupProjects($grupo);

		if ($result["status"] == "SUCCESS"){
			echo json_encode($result);
		}
		else{
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
}

function profeSaveProjects()
{
	if (isset($_SESSION["profeId"])) {

		$idA = $_POST["idA"];
		$pNombreA = $_POST["pNombreA"];
		$rankA = $_POST["rankA"];
		$aptoA = $_POST["aptoA"];

		$result = attemptProfeSaveProjects($idA, $pNombreA, $rankA, $aptoA);

		if ($result["status"] == "SUCCESS"){
			echo json_encode($result);
		}
		else{
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
}

function reviewProject()
{
	if (isset($_SESSION["profeId"])) {

		$project = $_POST["project"];

		$result = attemptReviewProject($project);

		if ($result["status"] == "SUCCESS"){
			echo json_encode($result);
		}
		else{
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
}

function feedbackProject()
{
	if (isset($_SESSION["profeId"])) {

		$project = $_POST["project"];
		$cText = $_POST["cText"];

		$result = attemptFeedbackProject($project, $cText);

		if ($result["status"] == "SUCCESS"){
			echo json_encode($result);
		}
		else{
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
}

function logoutProfe()
{
	session_unset();
	session_destroy();
	if (isset($_SESSION["profeId"])){
		header('HTTP/1.1 500' . "Logut error");
		die("Logut error");
	}
	else {
		echo json_encode(array("status" => "SUCCESS"));
	}
}

// --------------------------------------- ALUMNO --------------------------------

function loginAlumnoFunction()
{
	$alumnoId = $_POST["alumnoId"];
	$password = $_POST["password"];

	$result = attemptLoginAlumno($alumnoId, $password);

	if ($result["status"] == "SUCCESS"){
		$response = array('nombre' => $_SESSION['nombre'], 'carrera' => $_SESSION['carrera']);
		echo json_encode($response);
	}
	else{
		header('HTTP/1.1 500' . $result["status"]);
		die($result["status"]);
	}
}

function loadPreviousProjects()
{
	if (isset($_SESSION["alumnoId"])){
		$result = attemptLoadPreviousProjects();

		if ($result["status"] == "SUCCESS" || $result["status"] == "NO MATCHES FOUND"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
	else{
		header('HTTP/1.1 500' . "NO SESSION");
		die("NO SESSION");
	}
}

function registerProject()
{
	if (isset($_SESSION["alumnoId"]))
	{
		$grupo = $_SESSION["grupo"];
		$nombre = utf8_decode($_POST["nombre"]);
		$empresa = utf8_decode($_POST["empresa"]);
		$descripcion = utf8_decode($_POST["descripcion"]);
		$clasificacion = utf8_decode($_POST["clasificacion"]);
		$giro = utf8_decode($_POST["giro"]);
		$integrantes = $_POST["integrantes"];
		$nombreA = $_POST["nombreArr"];
		$matriculaA = $_POST["matriculaArr"];
		$carreraA = $_POST["carreraArr"];
		$emailAcademicoA = $_POST["emailAcademicoArr"];
		$emailPersonalA = $_POST["emailPersonalArr"];
		$celularA = $_POST["celularArr"];

		$result = attemptRegisterProject($grupo, $nombre, $empresa, $descripcion, $clasificacion, $giro, $integrantes, $nombreA, $matriculaA, $carreraA,
			$emailAcademicoA, $emailPersonalA, $celularA);

		if ($result["status"] == "SUCCESS"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
	else{
		header('HTTP/1.1 500' . "NO SESSION");
		die("NO SESSION");
	}
}

function checkAlumno()
{
	if (isset($_SESSION["alumnoId"]))
	{
		$alumno = $_SESSION["alumnoId"];

		$result = attemptLoadMyProject($alumno);

		if ($result["status"] == "SUCCESS" || $result["status"] == "NO MATCHES FOUND"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
}

function searchProjectsFunction()
{
	if (isset($_SESSION["alumnoId"])){

		$search = $_POST["search"];

		$result = attemptSearchProjects($search);

		if ($result["status"] == "SUCCESS" || $result["status"] == "NO MATCHES FOUND"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
	else{
		header('HTTP/1.1 500' . "NO SESSION");
		die("NO SESSION");
	}
}

function editProject()
{
	if (isset($_SESSION["alumnoId"]))
	{
		$proyecto = $_POST["proyecto"];
		$nombre = utf8_decode($_POST["nombre"]);
		$empresa = utf8_decode($_POST["empresa"]);
		$descripcion = utf8_decode($_POST["descripcion"]);
		$clasificacion = utf8_decode($_POST["clasificacion"]);
		$giro = utf8_decode($_POST["giro"]);

		$result = attemptEditProject($proyecto, $nombre, $empresa, $descripcion, $clasificacion, $giro);

		if ($result["status"] == "SUCCESS"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}		
	}
	else{
		header('HTTP/1.1 500' . "NO SESSION");
		die("NO SESSION");
	}
}

function logoutAlumno()
{
	session_unset();
	session_destroy();
	if (isset($_SESSION["alumnoId"])){
		header('HTTP/1.1 500' . "Logut error");
		die("Logut error");
	}
	else {
		echo json_encode(array("status" => "SUCCESS"));
	}
}

// --------------------------------- ADMIN -----------------------------------------

function loginAdminFunction()
{
	$adminId = $_POST["adminId"];
	$password = $_POST["password"];

	$result = attemptLoginAdmin($adminId, $password);

	if ($result["status"] == "SUCCESS"){
		echo json_encode($result);
	}
	else{
		header('HTTP/1.1 500' . $result["status"]);
		die($result["status"]);
	}
}

function logoutAdmin()
{
	session_unset();
	session_destroy();
	if (isset($_SESSION["adminId"])){
		header('HTTP/1.1 500' . "Logut error");
		die("Logut error");
	}
	else {
		echo json_encode(array("status" => "SUCCESS"));
	}
}

function loadProjectsAdmin()
{
	if (isset($_SESSION["adminId"])){
		$result = attemptLoadProjectsAdmin();

		if ($result["status"] == "SUCCESS" || $result["status"] == "NO MATCHES FOUND"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
	else{
		header('HTTP/1.1 500' . "NO SESSION");
		die("NO SESSION");
	}
}

function searchProjectsAdmin()
{
	if (isset($_SESSION["adminId"])){

		$search = $_POST["search"];

		$result = attemptSearchProjectsAdmin($search);

		if ($result["status"] == "SUCCESS" || $result["status"] == "NO MATCHES FOUND"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
	else{
		header('HTTP/1.1 500' . "NO SESSION");
		die("NO SESSION");
	}
}

function generarLista()
{
	if (isset($_SESSION["adminId"])){
		$result = attemptGenerarLista();

		if ($result["status"] == "SUCCESS" || $result["status"] == "NO MATCHES FOUND"){
			echo json_encode($result);
		}
		else {
			header('HTTP/1.1 500' . $result["status"]);
			die($result["status"]);
		}
	}
	else{
		header('HTTP/1.1 500' . "NO SESSION");
		die("NO SESSION");
	}
}

?>